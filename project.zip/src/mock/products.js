export const products = [
  {
    id: 1,
    name: "Muñeco Amigurumi 'Osito Soñador'",
    description: "Un tierno osito tejido a mano, perfecto para abrazar y soñar.",
    price: "$25.00",
    image: "https://via.placeholder.com/400x300/FFC0CB/FFFFFF?text=Osito+Soñador"
  },
  {
    id: 2,
    name: "Llavero 'Flor de Lirio'",
    description: "Llavero delicado con una flor de lirio tejida, ideal para tus llaves o bolso.",
    price: "$10.00",
    image: "https://via.placeholder.com/400x300/F0E68C/FFFFFF?text=Flor+de+Lirio"
  },
  {
    id: 3,
    name: "Ramo de Flores Eternas",
    description: "Un ramo de flores de crochet que nunca se marchitarán, un regalo para siempre.",
    price: "$45.00",
    image: "https://via.placeholder.com/400x300/ADD8E6/FFFFFF?text=Ramo+Eterno"
  },
  {
    id: 4,
    name: "Sonajero 'Conejo Saltarín'",
    description: "Sonajero suave y seguro para bebés, con forma de conejito.",
    price: "$20.00",
    image: "https://via.placeholder.com/400x300/DDA0DD/FFFFFF?text=Conejo+Saltarín"
  },
  {
    id: 5,
    name: "Posavasos 'Margarita'",
    description: "Set de posavasos con diseño de margarita, alegra tu mesa.",
    price: "$18.00",
    image: "https://via.placeholder.com/400x300/98FB98/FFFFFF?text=Posavasos+Margarita"
  },
  {
    id: 6,
    name: "Amigurumi 'Gatito Juguetón'",
    description: "Un adorable gatito amigurumi, compañero de aventuras.",
    price: "$30.00",
    image: "https://via.placeholder.com/400x300/FFDAB9/FFFFFF?text=Gatito+Juguetón"
  }
];